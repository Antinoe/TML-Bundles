using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;
using Microsoft.Xna.Framework.Input; //Allows Left Shift to be detected.


namespace Bundles.Items
{
	public class LeatherBundle : BaseBundle
	{
		//DO NOT REMOVE THIS.
		private List<Item> itemList = new List<Item>();
		
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Leather Bundle");
			Tooltip.SetDefault("Max Capacity: 99" + "\nRight-Click with items in hand to stow them." + "\nRight-Click with an empty hand to withdraw items." + "\nShift-Right-Click to withdraw in reverse order." + "\nContains:");
		}
		
		//DO NOT REMOVE THIS.
		public override void ModifyTooltips(List<TooltipLine> tooltips)
		{
			foreach (Item item in Enumerable.Reverse<Item>(this.itemList))
			{
				tooltips.Add(new TooltipLine(base.Mod, "ItemInfo", item.HoverName));
			}
		}
		
		//DO NOT REMOVE THIS.
		public override void RightClick(Player player)
		{
			int totalItems = 0; //Total Capacity.
			int maxItems = 99; //Max Capacity.
			foreach (var Item in itemList)
			{
				totalItems += Item.stack;
			}
			
			if (player.whoAmI == Main.myPlayer)
			{
				if (!Main.mouseItem.IsAir) //If an item is in hand.
				{
					if (Main.mouseItem.stack <= maxItems - totalItems) //If the item stack in hand is less than or equal to the Max Capacity minus the Total Capacity.
					{
						if (Main.mouseItem.maxStack > 1) //If the item isn't an Unstackable.
						{
							this.itemList.Add(Main.mouseItem.Clone());
							Main.mouseItem.TurnToAir();
							return;
						}
					}
				}
				else //If nothing is in hand.
				{
					if (this.itemList.Count != 0) //If the bundle contains an item or more.
					{
						if (Main.keyState.IsKeyDown(Keys.LeftShift)) //If holding Left Shift.
						{
							Item item = Enumerable.First<Item>(this.itemList);
							Main.mouseItem = item.Clone();
							this.itemList.Remove(item);
						}
						else //If not holding Left Shift.
						{
							Item item = Enumerable.Last<Item>(this.itemList);
							Main.mouseItem = item.Clone();
							this.itemList.Remove(item);
						}
					}
				}
			}
		}
		
		public override void AddRecipes()
		{
			CreateRecipe(1)
            .AddIngredient(ItemID.Leather, 10)
			.AddTile(TileID.Loom)
            .Register();
		}
		
		//DO NOT REMOVE THIS.
		//Start: Code that disallows the "Universal Item List" bug.
		public override void OnCreate(ItemCreationContext context)
        {
			itemList = new List<Item>();
        }
		
		//DO NOT REMOVE THIS.
		//Make sure to change the "BaseBundle" term within this to the name of your custom bundle.
        public override ModItem Clone(Item Item)
        {
            LeatherBundle clone = (LeatherBundle)base.Clone(Item);
            clone.itemList = itemList.Select(Item => Item.Clone()).ToList();
            return clone;
        }
		//End: Code that disallows the "Universal Item List" bug.
		
		//DO NOT REMOVE THIS.
		//Start: Save/Load Data stuff.
		public override void SaveData(TagCompound tag)
		{
			List<TagCompound> itemlist = new List<TagCompound>();
			foreach (Item item in this.itemList)
			{
				itemlist.Add(ItemIO.Save(item));
			}
			tag.Add("itemList", itemlist);
		}

		public override void LoadData(TagCompound tag)
		{
			this.itemList.Clear();
			foreach (TagCompound tag2 in Enumerable.ToList<TagCompound>(tag.GetList<TagCompound>("itemList")))
			{
				this.itemList.Add(ItemIO.Load(tag2));
			}
		}

		public override void NetSend(BinaryWriter writer)
		{
			writer.Write(this.itemList.Count);
			foreach (Item item in this.itemList)
			{
				ItemIO.Send(item, writer, true, false);
			}
		}

		public override void NetReceive(BinaryReader reader)
		{
			this.itemList.Clear();
			int count = reader.ReadInt32();
			for (int i = 0; i < count; i++)
			{
				this.itemList.Add(ItemIO.Receive(reader, true, false));
			}
		}
		//End: Save/Load Data stuff.
	}
}